/**
 * Reading and writing from supported files. This is the API 
 * for reading and writing module.
 */
#include "ts_error.h"
 
#ifndef __TS_STATE_H__
#define __TS_STATE_H__

ts_error_t ts_read_temp(const char* filename, float* current_temp);
ts_error_t ts_read_state(const char* filename, int* current_state_value);
ts_error_t ts_write_state(const char* filename, char state[]);

#endif
