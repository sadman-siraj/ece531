#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <errno.h>
#include <curl/curl.h>

#include "ts_state.h"

ts_error_t ts_read_temp(const char* filename, float* result) {
	FILE* fp = fopen(filename, "rb");
	ts_error_t retcode = OK;
	if (fp == NULL) {
		return NO_OPEN;
	}
	
	char buffer[32];
	fgets(buffer, sizeof(buffer), fp);
	*result = atof(buffer);
	
	fclose(fp);
	return retcode;
}

ts_error_t ts_read_state(const char* filename, int* result) {
	FILE* fp = fopen(filename, "rb");
	ts_error_t retcode = OK;
	if (fp == NULL) {
		return NO_OPEN;
	}
	
	char buffer[50];
	fgets(buffer, sizeof(buffer), fp);
	if (strstr(buffer, "ON")) *result = 1;
	else if (strstr(buffer, "OFF")) *result = 0;
	else *result = 1;
	
	fclose(fp);
	return retcode;
}

ts_error_t ts_write_state(const char* filename, char state[]) {
	FILE* fp = fopen(filename, "wb");
	ts_error_t retcode = OK;
	if (fp == NULL) {
		return NO_OPEN;
	}
	
	fprintf(fp, "%s\n", state);
	
	fclose(fp);
	return retcode;
}
