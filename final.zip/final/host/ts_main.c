#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <unistd.h>
#include <syslog.h>
#include <errno.h>
#include <signal.h>
#include <inttypes.h>
#include <string.h>
#include <time.h>
#include <curl/curl.h>
#include <argp.h>

#include "ts_error.h"
#include "ts_state.h"

static const char* DAEMON_NAME     = "tssimd";
static const char* TEMP_FILENAME   = "/tmp/temp";
static const char* STATE_FILENAME  = "/tmp/status";
static const char* WORKING_DIR     = "/";

static const long SLEEP_DELAY      = 5;

static const char* WEB_FILENAME    = "/tmp/set_points.txt";
static char* CONFIG_FILENAME = "./CONFIG.txt";
static char* GET_URL = "http://52.9.99.142/set_points.php";
static char* POST_URL = "http://52.9.99.142/set_actions.php";

char* response[9];
char* set_time_range[3];
char* set_temp_range[3];
char* set_time[6];
char* set_hour[6];
char* set_temp[6];

char temp_file[50];
char state_file[50];
char get_url[50];
char post_url[50];

static void _exit_process(const ts_error_t err) {
	syslog(LOG_INFO, "%s", ts_error_to_msg(err));
	closelog();
	exit(err);
}

static void _signal_handler(const int signal) {
	switch(signal) {
		case SIGHUP:
			break;
		
		case SIGTERM:
			_exit_process(RECV_SIGTERM);
			break;
		default:
			syslog(LOG_INFO, "received unhandled signal");
	}
}

static void _handle_fork(const pid_t pid) {
	// Unable to fork
	if (pid < 0) {
		_exit_process(NO_FORK);
	}
	// Fork successful, exit parent process
	if (pid > 0) {
		exit(OK);
	}
}

static void _daemonize(void) {
	// Fork from the parent process
	pid_t pid = fork();
	
	// Open syslog with the specified logmask
	openlog(DAEMON_NAME, LOG_PID | LOG_NDELAY | LOG_NOWAIT, LOG_DAEMON);
	
	// Handle the results of the fork
	_handle_fork(pid);
	
	// Now become the session leader
	if (setsid() < -1) {
		_exit_process(NO_SETSID);
	}
	
	// Set our custom signal handling
	signal(SIGTERM, _signal_handler);
	signal(SIGHUP, _signal_handler);
	
	// New file persmissions on this process, they need to be permissive.
        //umask(S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
        //umask(666);
	
	// Change to the working directory
	chdir(WORKING_DIR);
	
	// Closing this descriptors (STDIN, STDOUT, etc.)
	for (long x = sysconf(_SC_OPEN_MAX); x>=0; x--) {
		close(x);
	}
}

size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream) {
	size_t written = fwrite(ptr, size, nmemb, stream);
	return written;
}

static void _get_webdata(void) {
	CURL *curl;
	CURLcode res;
	curl_global_init(CURL_GLOBAL_DEFAULT);
	curl = curl_easy_init();
	// char get_url[] ="http://52.9.99.142/set_points.php";
	FILE *fp = fopen(WEB_FILENAME, "wb");
	// ts_error_t retcode = OK;
	if (fp == NULL) {
		_exit_process(NO_OPEN);
	}
	
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, get_url);
		// curl_easy_setopt(curl, CURLOPT_POST, 1L);
		// curl_easy_setopt(curl, CURLOPT_POSTFIELDS, request);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
		res = curl_easy_perform(curl);
		if (res != CURLE_OK) {
			_exit_process(CURL_FAILURE);
		}
		curl_easy_cleanup(curl);
	}
	curl_global_cleanup();
	fclose(fp);
	// return retcode;
}

static void _run_simulation(void) {

	syslog(LOG_INFO, "beginning thermostat simulation");

	int heater_state = 0; // 1 = ON, 0 = OFF
	char heater_action[2][5] = {"OFF", "ON"}; // [0, 1] = ["OFF", "ON"]
	int set_range = 0;
	char current_state[2][20] = {"HEATER IS OFF", "HEATER IS ON"};
	char action[2][20] = {"TURN OFF HEATER", "TURN ON HEATER"};
	char* set_temp_l[3] = {set_temp[0], set_temp[2], set_temp[4]};
	char* set_temp_h[3] = {set_temp[1], set_temp[3], set_temp[5]};
	int prev_heater_state = 1;
	
	while(true) {
		syslog(LOG_INFO, "Reading current temperature...\n");
		float current_temp = 0.0;
		ts_error_t err = ts_read_temp(temp_file, &current_temp);
		if (err != OK) _exit_process(err);
		
		syslog(LOG_INFO, "Reading current heater state...\n");
		int current_state_value = 0;
		err = ts_read_state(state_file, &current_state_value);
		if (err != OK) _exit_process(err);
		
		syslog(LOG_INFO, "Comparing time ranges...\n");
		time_t present_time = time(NULL);
		struct tm *ptm = localtime(&present_time);
		
		if (ptm->tm_hour >= atoi(set_hour[0]) && ptm->tm_hour < atoi(set_hour[1])) {
			if (current_temp < atof(set_temp[0])) heater_state = 1;
			if (current_temp > atof(set_temp[1])) heater_state = 0;
			set_range = 1;
		}
		else if (ptm->tm_hour >= atoi(set_hour[2]) && ptm->tm_hour < atoi(set_hour[3])) {
			if (current_temp < atof(set_temp[2])) heater_state = 1;
			if (current_temp > atof(set_temp[3])) heater_state = 0;
			set_range = 2;
		} 
		else if (ptm->tm_hour >= atoi(set_hour[4]) && ptm->tm_hour < 24) {
			if (current_temp < atof(set_temp[4])) heater_state = 1;
			if (current_temp > atof(set_temp[5])) heater_state = 0;
			set_range = 3;
		}
		
		syslog(LOG_INFO, "Writing new heater state...\n");
		char new_state[] = "HEATER IS "; // OFF/ON
		strcat(new_state, heater_action[heater_state]);
		err = ts_write_state(state_file, new_state);
		if (err != OK) _exit_process(err);
		
		char current_hour[10];
		char current_min[10];
		char current_sec[10];
		char current_temp_str[10];
		sprintf(current_hour, "%d", ptm->tm_hour);
		sprintf(current_min, "%d", ptm->tm_min);
		sprintf(current_sec, "%d", ptm->tm_sec);
		sprintf(current_temp_str, "%f", current_temp);
		
		if (prev_heater_state != heater_state) {
			syslog(LOG_INFO, "Posting status and action...\n");
			char post_data[200] = "curl ";
			strcat(post_data, post_url);
			strcat(post_data, " -d \"REQUEST=PUT&TIMESTAMP=");
			strcat(post_data, current_hour);
			strcat(post_data, ":");
			strcat(post_data, current_min);
			strcat(post_data, ":");
			strcat(post_data, current_sec);
			strcat(post_data, "&TEMPERATURE=");
			strcat(post_data, current_temp_str);
			strcat(post_data, "&SET_POINTS=");
			strcat(post_data, set_temp_l[set_range-1]);
			strcat(post_data, "-");
			strcat(post_data, set_temp_h[set_range-1]);
			strcat(post_data, "&CURRENT_STATUS=");
			strcat(post_data, current_state[current_state_value]);
			strcat(post_data, "&ACTION=");
			strcat(post_data, action[heater_state]);
			strcat(post_data, "\"");

			system(post_data);
		}
		
		prev_heater_state = heater_state;
		
		sleep(SLEEP_DELAY);
	}
}

// Program documentation
static char doc[] = "tssimd -- a thermostat simulation to read temperatures and write heater states";

// Argument description
static char args_doc[] = "config_file = Please put the name of the config file here with the location to the file in the format: /file_location/filename";

// Program options
static struct argp_option options[] = {
	{"config_file", 'c', "FILENAME", 0, "Set configuration file for the program. Otherwise, default configuration file \"./CONFIG.txt\" will be used."},
	{ 0 }
};

// Used by main to communicate with parse_opt
struct arguments {
	char *config_file;
	int user_input;
};

// Parse a single option
static error_t parse_opt(int key, char *arg, struct argp_state *state) {
	struct arguments *arguments = state->input;
	
	switch (key) {
		case 'c':
			syslog(LOG_INFO, "Reading user configuration file...\n");
			arguments->config_file = arg;
			arguments->user_input = 1;
			break;
		/*
		case ARGP_KEY_ARG:
			if (state->arg_num > 1) {
				// Too many arguments
				argp_usage(state);
			}
			break;
			
		case ARGP_KEY_END:
			if (state->arg_num < 1) {
				// Not enough arguments
				argp_usage(state);
			}
			break;
			
		default:
			break;
			//return ARGP_ERR_UNKNOWN;
		*/
	}
	return 0;
}

// argp parser
static struct argp argp = { options, parse_opt, args_doc, doc };

int main(int argc, char **argv) {

	struct arguments arguments;
	
	// Default values
	arguments.config_file = CONFIG_FILENAME;
	arguments.user_input = 0;
	strcpy(temp_file, TEMP_FILENAME);
	strcpy(state_file, STATE_FILENAME);
	strcpy(get_url, GET_URL);
	strcpy(post_url, POST_URL);
	
	// Parsing user given arguments
	argp_parse(&argp, argc, argv, 0, 0, &arguments);
	
	
	if (arguments.user_input) {
		FILE *fp = fopen(arguments.config_file, "rb");
		if (fp == NULL) {
			_exit_process(NO_OPEN);
		}
		char buf[1000];
		int line_count = 1;
		while(fgets(buf, 1000, fp) != NULL) {
			if (line_count == 2) {
				strcpy(temp_file, buf);
				temp_file[strcspn(temp_file, "\n")] = 0;
			}
			if (line_count == 5) {
				strcpy(state_file, buf);
				state_file[strcspn(state_file, "\n")] = 0;
			}
			if (line_count == 8) {
				strcpy(get_url, buf);
				get_url[strcspn(get_url, "\n")] = 0;
			}
			if (line_count == 11) {
				strcpy(post_url, buf);
				post_url[strcspn(post_url, "\n")] = 0;
			}
			line_count++;
		}
		fclose(fp);
		syslog(LOG_INFO, "Using CONFIGURATION FILE = %s\n", arguments.config_file);
		syslog(LOG_INFO, "Using TEMP file: %s\n", temp_file);
		syslog(LOG_INFO, "Using STATE file: %s\n", state_file);
		syslog(LOG_INFO, "Using GET URL: %s\n", get_url);
		syslog(LOG_INFO, "Using POST URL: %s\n", post_url);
		//printf("Using CONFIGURATION FILE = %s\n", arguments.config_file);
		// printf("Using TEMP file: %s\n", temp_file);
		// printf("Using STATE file: %s\n", state_file);
		// printf("Using GET URL: %s\n", get_url);
		// printf("Using POST URL: %s\n", post_url);
	}
	else {
		syslog(LOG_INFO, "Using CONFIGURATION FILE = %s (Default CONFIGURATION FILE)\n", arguments.config_file);
		syslog(LOG_INFO, "Using TEMP file: %s\n", temp_file);
		syslog(LOG_INFO, "Using STATE file: %s\n", state_file);
		syslog(LOG_INFO, "Using GET URL: %s\n", get_url);
		syslog(LOG_INFO, "Using POST URL: %s\n", post_url);
		// printf("Using CONFIGURATION FILE = %s (Default CONFIGURATION FILE)\n", arguments.config_file);
		// printf("TEMP file: %s\n", temp_file);
		// printf("TEMP file: %s\n", temp_file);
		// printf("STATE file: %s\n", state_file);
		// printf("GET URL: %s\n", get_url);
		// printf("POST URL: %s\n", post_url);
	}

	syslog(LOG_INFO, "Getting set temperature programs...\n");
	_get_webdata();

	FILE *fp = fopen(WEB_FILENAME, "rb");
	if (fp == NULL) {
		_exit_process(NO_OPEN);
	}
	
	char buf[1000];
	int line_count = 1;
	
	while(fgets(buf, 1000, fp) != NULL) {
       	if (line_count == 14) {
       		// printf("%s", buf);
       		char * token = strtok(buf, "</td></tr><tr><td>");
       		int loop_counter = 0;
       		while (token != NULL) {
       			// printf("%s\n", token);
       			response[loop_counter] = token;
       			// printf("%s\n", response[loop_counter]);
       			loop_counter++;
       			token = strtok(NULL, "</td></tr><tr><td>");
       		}
       		break;
       	}
		line_count++;
	}
	fclose(fp);
	
	set_time_range[0] = response[1];
	set_time_range[1] = response[4]; 
	set_time_range[2] = response[7];
	
	set_temp_range[0] = response[2]; 
	set_temp_range[1] = response[5]; 
	set_temp_range[2] = response[8];

	int loop_counter = 0;
	for (int i = 0; i < 3; i++) {
		char * token = strtok(set_time_range[i], "-");
		while (token != NULL) {
			set_time[loop_counter] = token;
			loop_counter++;
			token = strtok(NULL, "-");
		}
	}
	
	loop_counter = 0;
	for (int i = 0; i < 3; i++) {
		char * token = strtok(set_temp_range[i], "-");
		while (token != NULL) {
			set_temp[loop_counter] = token;
			loop_counter++;
			token = strtok(NULL, "-");
		}
	}
	
	for (int i = 0; i < 6; i++) {
		char * token = strtok(set_time[i], ":");
		while (token != NULL) {
		set_hour[i] = token;
		break;
		}
	}

	// Daemonize the process
	_daemonize();
	
	// Execute the primary daemon routines
	_run_simulation();
	
	// If we get here, something weird has happened
	return OK;
}
